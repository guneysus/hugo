from distutils.core import setup

setup(
    name='kahya',
    version='0.0.1',
    packages=['kahya'],
    url='',
    license='BSD-3',
    author='',
    author_email='serefguneysu@gmail.com',
    description='kahya'
)
