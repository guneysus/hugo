kahya
=========

Tue Nov 15 23:42:46 2016 +0300

Joker uygulamasının web sitesinde iki ayrı Android ve iOS linki olması
beni rahatsız etti. Bir kaç saatte Python ile PoF yapıp gönderdim.

Ahmet AYGÜN aynı fikirden yola çıkarak GO ile baştan yazarak projeye
*Ajan* ismini verdi.

[ajan](https://github.com/ahmet/ajan/tree/d67a6c3b443329cbd8fb6e840aa16730ae02706c#thanks)
