const App = (function () {
    var hasUserMedia = () => !!navigator.getUserMedia;

    var init = function (el) {
        if (!hasUserMedia()) {
            throw ("Error. WebRTC is not supported!");
        }

        // get both video/audio streams from user's camera 
        // TODO can be converted to promise
        navigator.getUserMedia({
            video: true,
            audio: false
        }, function (stream) {
            var video = document.querySelector('video');
            if (typeof video.srcObject == "object") {
                video.srcObject = stream;
            } else {
                video.src = URL.createObjectURL(stream);
            }                        
        }, function (err) {
            debugger
        })
    }

    return {
        hasUserMedia: hasUserMedia,
        init: init,
    }
})()


App.init()

window.App = App