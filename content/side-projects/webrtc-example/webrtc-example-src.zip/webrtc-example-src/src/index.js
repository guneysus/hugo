// index.js

// import Vue from 'vue';
// import adapter from 'webrtc-adapter/out/adapter.js';

require('./app.js')

require('./main.css')
require('./styles.css')

const app = (a, b) => {
   return a + b;
}

console.log(app(4,5));