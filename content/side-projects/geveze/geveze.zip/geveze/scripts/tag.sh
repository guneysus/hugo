#!/usr/bin/env bash

git tag `cat VERSION`
