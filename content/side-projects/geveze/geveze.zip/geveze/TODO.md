GEVEZE EVENTS

## base events

```
    joined = 10
    joined_first = 11
    joined_again = 12
    joined_newtab = 13

    left = 20
    closed_tab = 21

    sent_message = 30
    sent_photo = 31
    sent_video = 32
    sent_audio = 33
    sent_file = 34

    avatar = 40
    sent_avatar_info = 41
    changed_avatar = 42
```    
