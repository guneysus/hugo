# geveze
fullstack  tornado websocket chat example 

## how to try
```sh
docker run --publish 8000:8000 -it guneysu/geveze:latest
xdg-open http://localhost:8000
```

![image](https://cloud.githubusercontent.com/assets/949232/17839854/f2906a92-67fd-11e6-8c8f-ac11b01b4701.png)


![image](https://cloud.githubusercontent.com/assets/949232/17638528/3835787e-60f3-11e6-8b77-174d5e9dd4dd.png)


![image](https://cloud.githubusercontent.com/assets/949232/17638547/5b57b984-60f3-11e6-80ad-1e961a57365a.png)

![image](https://cloud.githubusercontent.com/assets/949232/17638564/8fe9cf98-60f3-11e6-9c87-5618cd9cef5b.png)
