#!/usr/bin/env python
# coding:utf-8

import unittest


# noinspection PyMethodParameters
class GevezeTests(unittest.TestCase):
    pass


if __name__ == '__main__':
    unittest.main()
