  export var data = {
    messages: [
      '✋', '😁',
      'hi...',
      'www.google.com',
      'mailto:serefguneysu@gmail.com',
      "intent://scan/#Intent;scheme=zxing;package=com.google.zxing.client.android;S.browser_fallback_url=http%3A%2F%2Fzxing.org;end",
      "intent://scan/#Intent;scheme=zxing;package=com.google.zxing.client.android;end"
    ],

    images: [
      'http://placehold.it/200x200/bbaaaa/ffffff?text=image-1',
      'http://placehold.it/200x200/aabbaa/ffffff?text=image-2',
      'http://placehold.it/200x200/aaaabb/ffffff?text=image-3',
    ],
    videos: [
      'http://www.sample-videos.com/video/mkv/240/big_buck_bunny_240p_1mb.mkv',
      'http://www.sample-videos.com/video/mp4/240/big_buck_bunny_240p_1mb.mp4'
    ],
    audios: [
      'http://www.w3schools.com/html/horse.ogg'
    ],
    pdfs: [
      'http://www.publishers.org.uk/_resources/assets/attachment/full/0/2091.pdf'
    ],
    files: [
      'http://humanstxt.org/humans.txt'
    ]
  }