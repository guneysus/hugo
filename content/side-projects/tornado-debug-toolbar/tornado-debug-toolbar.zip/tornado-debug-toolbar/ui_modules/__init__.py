#!/usr/bin/env python
# coding: utf-8

import tornado.web


class DebugModule(tornado.web.UIModule):
    def render(self, item):
        return self.render_string("modules/debug.html", item=item)


class DebugSubmodule(tornado.web.UIModule):
    def render(self, item):
        return self.render_string("modules/debug-submodule.html", item=item)


class EntryListItem(tornado.web.UIModule):
    def render(self, model):
        return self.render_string("modules/entry/item.html", model=model)

