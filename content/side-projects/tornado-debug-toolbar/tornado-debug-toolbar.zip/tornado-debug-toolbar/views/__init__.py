#!/usr/bin/env python
# coding: utf-8

import functools

try:
    from google.appengine.api import users
except ImportError as e:
    pass

import os
import tornado.web
import tornado.websocket


# import tornado.httpclient
# http_client = tornado.httpclient.HTTPClient()


def login_required(method):
    """Decorate with this method to restrict to site admins."""

    @functools.wraps(method)
    def wrapper(self, admin=False, *args, **kwargs):
        if not self.current_user:
            if self.request.method == "GET":
                self.redirect(self.get_login_url())
                return
            raise tornado.web.HTTPError(403)
        else:
            return method(self, *args, **kwargs)

    return wrapper


def administrator(method):
    """Decorate with this method to restrict to site admins."""

    @functools.wraps(method)
    def wrapper(self, *args, **kwargs):
        if not self.current_user:
            if self.request.method == "GET":
                self.redirect(self.get_login_url())
                return
            raise tornado.web.HTTPError(403)
        if not self.current_user.is_admin:
            raise tornado.web.HTTPError(403)
        else:
            return method(self, *args, **kwargs)

    return wrapper


# noinspection PyAbstractClass
class NotFoundHandler(tornado.web.RequestHandler):
    status = dict(status_code=404, reason='End point not found')
    status404 = """
    <style>
    pre {
        padding: 1em;
        top: 100px;
        margin: 0 auto;
    }
    body {
        color: rgb(0,255,0);
        background-color: black;
    }
    </style>
    <pre style="">
           444444444       000000000            444444444
          4::::::::4     00:::::::::00         4::::::::4
         4:::::::::4   00:::::::::::::00      4:::::::::4
        4::::44::::4  0:::::::000:::::::0    4::::44::::4
       4::::4 4::::4  0::::::0   0::::::0   4::::4 4::::4
      4::::4  4::::4  0:::::0     0:::::0  4::::4  4::::4
     4::::4   4::::4  0:::::0     0:::::0 4::::4   4::::4
    4::::444444::::4440:::::0 000 0:::::04::::444444::::444
    4::::::::::::::::40:::::0 000 0:::::04::::::::::::::::4
    4444444444:::::4440:::::0     0:::::04444444444:::::444
              4::::4  0:::::0     0:::::0          4::::4
              4::::4  0::::::0   0::::::0          4::::4
              4::::4  0:::::::000:::::::0          4::::4
            44::::::44 00:::::::::::::00         44::::::44
            4::::::::4   00:::::::::00           4::::::::4
            4444444444     000000000             4444444444
    </pre>
    """

    def data_received(self, chunk):
        pass

    def get(self):
        self.set_status(**self.status)
        self.render("base/404.html")

    def post(self):
        self.set_status(**self.status)
        self.write(self.status404)

    def put(self):
        self.set_status(**self.status)

    def patch(self):
        self.set_status(**self.status)

    def head(self):
        self.set_status(**self.status)

    def options(self):
        self.set_status(**self.status)

    def delete(self):
        self.set_status(**self.status)


class BaseHandler(tornado.web.RequestHandler):
    """Implements Google Accounts authentication methods."""

    @property
    def login_url(self):
        return users.create_login_url(self.request.uri)

    def get_current_user(self):
        user = users.get_current_user()
        if user:
            if users.is_current_user_admin():
                user.is_admin = users.is_current_user_admin()
            else:
                user.is_admin = False
        return user

    def get_login_url(self):
        return users.create_login_url(self.request.uri)

    def render_string(self, template_name, **kwargs):
        # Let the templates access the users module to generate login URLs
        return tornado.web.RequestHandler.render_string(
            self, template_name, users=users, **kwargs)


class ServerInfo(BaseHandler):
    @administrator
    def get(self):
        self.add_header('content-type', 'text/html')
        data = dict(os.environ)
        for k, v in sorted(data.iteritems()):
            d = '<b>%s</b>: %s<br>' % (k, v)
            self.write(d)


class Home(BaseHandler):
    def get(self):
        self.render("index.html")


class Composer(BaseHandler):
    @administrator
    def get(self, nid=0):
        self.render("cms/composer.html", entry=None)


class CMS(BaseHandler):
    def fake_entries(self):
        return [{"_id": {"$oid": "570599b7479e0c000b756b45"}, "title": "Markup Test", "nid": 1002, "summary": " "},
                {"_id": {"$oid": "570590c086c795000c62f693"}, "title": "Hangisini Seçmeliyim?", "nid": 1001,
                 "summary": "\"Alet işler el övünür\" cümlesindeki alet takıntısı üzerine bir kaç cümle."}]

    def entries(self):
        from google.appengine.api import urlfetch
        import json
        url = 'https://api.mlab.com/api/1/databases/blog/collections/posts?apiKey=%s' % self.application.APIKEY
        return json.loads(urlfetch.fetch(url).content)

    @administrator
    def get(self):
        # entries = self.entries()
        self.render("cms/index.html", model=self.fake_entries())


class EchoWebSocket(tornado.websocket.WebSocketHandler):
    def open(self):
        print("WebSocket opened")

    def on_message(self, message):
        self.write_message(u"You said: " + message)

    def on_close(self):
        print("WebSocket closed")
                
