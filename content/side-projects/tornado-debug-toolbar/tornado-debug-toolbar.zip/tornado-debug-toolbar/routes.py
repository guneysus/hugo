import os
import views
import tornado.web
from tornado.web import url

handlers = [
    url(r"/", views.Home, name='home'),
    url(r"/chat", views.EchoWebSocket, name='chat'),
    url(r"/_cms", views.CMS, name='contents'),
    url(r"/_cms/post/(?P<nid>[0-9]{4,})", views.Composer, name='post'),
    url(r"/_info", views.ServerInfo, name='server_info'),
    url(r'/static/(.*)', tornado.web.StaticFileHandler, {'path': os.path.join(os.path.dirname(__file__), "static")}),
    url(r".*", views.NotFoundHandler, name=404),
]

