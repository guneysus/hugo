#!/usr/bin/env python
# coding: utf-8


import wsgiref.handlers

import os
import routes
import tornado.wsgi
import ui_modules
from tornado.options import define, options, parse_command_line

define("compiled_template_cache", default=True)
define("gzip", default=False, help="compress_response")
parse_command_line()

DEVELOPMENT = os.environ.get('SERVER_SOFTWARE', '').startswith('Development')


class MainApp(tornado.web.Application):
    def __init__(self):
        # noinspection PyUnusedLocal
        self.APIKEY, self.APIBASE, self.DATABASE = os.environ['APIKEY'], \
                                    os.environ['APIBASE'],\
                                    os.environ['DATABASE']

        DEVELOPMENT = os.environ['DEVELOPMENT'].lower() == 'true'
        settings = dict(
            ui_modules=ui_modules,
            debug=DEVELOPMENT,
            xheaders=True,
            xsrf_cookies=True,
            compress_response=options.gzip,
            template_path=os.path.join(os.path.dirname(__file__), "templates"),
            static_path=os.path.join(os.path.dirname(__file__), "static"),
        )

        super(MainApp, self).__init__(handlers=routes.handlers, **settings)


wsgi = tornado.wsgi.WSGIAdapter(MainApp())

def ioloop():
    import tornado.httpserver
    import tornado.ioloop

    server = tornado.httpserver.HTTPServer(MainApp(), xheaders=True)
    server.bind(8080)
    server.start(1)

    tornado.ioloop.IOLoop.current().start()

def main():
    wsgiref.handlers.CGIHandler().run(wsgi)


if __name__ == "__main__":
    # main()
    ioloop()

