#!/usr/bin/env python
# https://unix.stackexchange.com/a/57939/38476

import tornado.ioloop
import tornado.web
import pprint
import json
from pprint import pprint as w
import urllib.parse

w = print

class InteractiveHandler(tornado.web.RequestHandler):
    def post(self):
        get_arg = self.get_body_argument

        payload = get_arg("payload", default=None, strip=False)

        model = json.loads(payload)
        callback_id = model['callback_id']
        user = model['user']['name']
        team = model['team']['domain']
        ts = model['action_ts']
        actions = model['actions']

        keys = ['user', 'team', 'callback_id', 'actions']
        for k in keys:
            w(k, ":", model[k])

class ActionHandler(tornado.web.RequestHandler):
    def post(self):
        get_arg = self.get_body_argument
        keys = ['token', 'team_domain', 'channel_name', 'user_name', 'command', 'text']

        for k in keys:
            w(k, ":", get_arg(k))

        # w(self.request.body)


if __name__ == "__main__":
    tornado.web.Application(
            [
                (r"/slack/interactive/.*", InteractiveHandler),
                (r"/slack/action/.*", ActionHandler),
            ]).listen(8080)
    tornado.ioloop.IOLoop.instance().start()
