#!/usr/bin/env bash

# WEBHOOK_URL=https://hooks.slack.com/services/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 # BA
WEBHOOK_URL=https://hooks.slack.com/services/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   # PERSONAL

# curl -X POST -H 'Content-type: application/json' --data @data/hello.json $WEBHOOK_URL
curl -X POST -H 'Content-type: application/json' --data @data/buttons.json $WEBHOOK_URL

