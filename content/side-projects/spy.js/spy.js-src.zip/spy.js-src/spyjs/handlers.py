#!/usr/bin/env python
# coding: utf-8
import json
import tornado.websocket

import tornado.web

from spyjs.core import SpyJs


class DashBoardHandler(tornado.web.RequestHandler, SpyJs):
    def get(self, *args, **kwargs):
        self.render('templates/dashboard.html', log=json.dumps(self.log))


class SpyJsHandler(tornado.web.RequestHandler, SpyJs):
    def get(self, *args, **kwargs):
        data = self.log_data(self.request)
        script = """
console.log("Hi, I\'m the spyjs");

window.spyjs = {data};
console.group('spyjs');
console.dir(spyjs);
console.groupEnd('spyjs');


        """.format(data=json.dumps(data, indent=2))
        self.set_header('content-type', 'application/javascript')

        self.finish(script)


class SpyJsApiHandler(tornado.web.RequestHandler, SpyJs):
    def get(self, *args, **kwargs):
        self.finish(dict(data=self.log))


class SpyjsWebsocketHandler(tornado.websocket.WebSocketHandler, SpyJs):
    clients = []

    def open(self):
        print("WebSocket opened")
        self.clients.append(self)

    def on_message(self, message):
        self.write_message(u"You said: " + message)

    def on_close(self):
        print("WebSocket closed")
