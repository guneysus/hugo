#!/usr/bin/env python
# coding: utf-8

import tornado.ioloop
import tornado.web
import tornado.httputil
import tornado.httpserver
from tornado.options import define, options


# noinspection PyAbstractClass
class MainHandler(tornado.web.RequestHandler):
    def get(self, *args):
        self.render(template_name='templates/index.html')


def make_app():
    urls = [
        (r"/(.*)", MainHandler),
    ]

    application = tornado.web.Application(
        handlers=urls,
        autoreload=options.autoreload,
        debug=options.debug)

    return application


if __name__ == "__main__":
    define('port', default=8000)
    define('debug', default=False)
    define('autoreload', default=False)

    options.parse_command_line()

    default = make_app()
    default.listen(options.port)

    default_server = tornado.httpserver.HTTPServer(default)

    tornado.ioloop.IOLoop.current().start()
