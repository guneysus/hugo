#!/usr/bin/env python
# coding: utf-8
import time

import tornado.httputil
import tornado.websocket
import spyjs.handlers


class SpyJs(object):
    log = []
    # noinspection PyMethodMayBeStatic
    def log_data(self, request: tornado.httputil.HTTPServerRequest):
        headers = dict(request.headers)
        cookies = dict(request.cookies)
        host = request.host

        data = dict(
            headers=headers,
            cookies=cookies,
            host=host,
            _timestamp=time.time(),
        )

        self.log.append(data)

        return data
