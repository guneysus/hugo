from setuptools import setup, find_packages

setup(
    name='spyjs',
    version='0.0.3',
    packages=find_packages(),
    url='',
    license='MIT',
    author='Ahmed Seref Guneysu',
    author_email='',
    description='Just a PoC/Experimental project',
    install_requires=[
        'tornado==5.0.1',
    ]
)
