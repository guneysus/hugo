

## TEST-1 nginx # of workers

# config-1  1 worker
# config-2  2 workers
# config-3  4 workers
# config-4  8 workers
# config-5  16 workers