# packathon2016

- Github  üzerinde proje açarken `LICENSE, README ve .gitignore` dosyalarını kolayça ekleyebiliyoruz.

- Peki ya, localimizde bunu yapsak güzel olmaz mı?

- Veya localdeki projenizi açtığımızda, Github üzerinde de yeni bir repository açılsa nasıl olur?

- Daha ileri gidelim. Bunu `packathon2016` da yetiştirebileceğimi düşünmüyorum ama proje türünüze göre tıpkı Yeoman gibi bir proje iskeleti `scaffold` edilse. (bkz. devpod#30, fikir @vigo'ya ait)



## İŞ ÜSTÜNDE
<iframe width="420" height="315" src="https://www.youtube.com/embed/38QqhDGxzPE" frameborder="0" allowfullscreen></iframe>


[![IMAGE ALT TEXT HERE](http://img.youtube.com/vi/38QqhDGxzPE/0.jpg)](https://www.youtube.com/watch?v=38QqhDGxzPE)


## KURULUM
- Bütün klasörlerde çalışabilmesi için `$PATH` içinde bir klasöre koyulması gerekiyor. Fakat henüz test etmedim.
- Github üzerinde repo açabilmek için https://github.com/settings/tokens adresinden `public_repo` veya `repo` işaretli şekilde yeni token alınması gerekiyor.
- Komut satırında:

```
$ export TOKEN=XXXXXX

```


## NASIL ÇALIŞIR
Şimdilik aşağıdaki şekillerde çalışabiliyor. `$PATH` içindeki bir yola kurulmasıyla alakalı henüz bir deneme yapmadım.

Ayrıca her lisans dosyasında *author*, *year* gibi değiştirilmesi gereken parametreler farklı şekilde tanımlandığı için, ("<year>, {yyyy},{year}, [year]") gibi bunların hepsini standartlaştırmak gerekiyor.
Bir kısmını tamamladım.

```
$ make run
$ python -m packathon2016
$ python packathon2016/__main__.py
```


### YAPILACAKLAR
- [x] LICENSE dosyalarımdaki placeholder'ların standartlaştırılması.
- [ ] Forma girilen veriler kaybolmadan validasyon yapılması veya hiç olmazsa formun boş bir şekilde yeniden açılması
- [x] Github API ile repository açılması
