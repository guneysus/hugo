#!/usr/bin/env python
# coding=utf-8
import logging

__author__ = u'Ahmed Şeref GÜNEYSU'
import npyscreen
from npyscreen import *
import sys
import os
import json
import requests
from requests.auth import HTTPBasicAuth
import datetime

licenses = json.loads(open('packathon2016/data/licenses.json').read())
ignores = [e for e in json.loads(open('packathon2016/data/ignore.json').read()) if
           e['type'] == 'file' and e['name'].endswith('.gitignore')]

license_keys = [e['key'] for e in licenses]
license_names = [e['name'] for e in licenses]
license_uris = [e['url'] for e in licenses]

gitignore_names = [k['name'].replace('.gitignore', '') for k in ignores]
gitignore_uris = ['http://www.google.com']


class App(NPSAppManaged):
    def onStart(self):
        self.registerForm("MAIN", MainForm("Add App Ya Hû..."))


class MainForm(ActionFormV2):
    types = ['Python', 'C#', 'Ruby', 'Javascript']

    def create(self):
        super(MainForm, self).create()
        self.author = self.add(TitleText, name='Username')
        self.folder = self.add(npyscreen.TitleFilenameCombo, name="Folder")
        self.repo = self.add(TitleText, name='Repository')
        # self.email = self.add(TitleText, name="E-mail")
        self.project = self.add(TitleText, name='Project Name')
        self.description = self.add(TitleText, name='Description')
        self.license = self.add(TitleSelectOne,
                                name='License',
                                max_height=5,
                                values=license_names
                                )

        # self.date = self.add(TitleDateCombo, name="Date", value=datetime.datetime.now())
        self.type = self.add(TitleSelectOne,
                             max_height=7,
                             name='Project Type',
                             values=gitignore_names,
                             scroll_exit=False)


def app_wrapper(*args):
    form = MainForm(name="Project Bootstrapper")
    form.edit()

    if len(form.license.value) == 1:
        uri = licenses[form.license.value[0]]['url']
    else:
        uri = 'https://api.github.com/licenses/unlicense'

    if form.license.value == []:
        license = 'unlicense'
    else:
        license = licenses[form.license.value[0]]['key']

    if form.type.value == []:
        ignore = ''
    else:
        ignore = ignores[form.type.value[0]]['name'].replace('.gitignore', '')

    # TODO Add Validation on click OK.
    # TODO Do not lose data
    #
    # if True:
    #     wrapper_basic(app_wrapper)

    return \
        dict(author=form.author.value,
             repo=form.repo.value,
             # email=form.email.value,
             project=form.project.value,
             description=form.description.value,
             license=license,
             ignore=ignore,
             folder=form.folder.value
             )


def main():
    formdata = wrapper_basic(app_wrapper)
    bootstrap(formdata)


def bootstrap(formdata):
    """
    :param formdata:
    :return:

     1. Create folder with project name
     2. Create README.md
     3. Create .gitignore file
     4. Create LICENSE file
     5. Execute `git init` in the project folder
     5. Set remote url
     6. Create Github repo

    """
    if not formdata.get('repo') or not formdata.get('folder'):
        logging.exception("Repository and Folder are required. Please try again.")
        sys.exit(99)

    # <editor-fold desc="Create Project Folder">
    repofullpath = os.path.abspath("{0}/{1}.git".format(formdata['folder'], formdata['repo']))

    if os.path.isdir(repofullpath):
        logging.error("The %s folder is exists. Remove and try again." % repofullpath)
        sys.exit(99)

    os.makedirs(repofullpath)
    # </editor-fold>

    # </editor-# <editor-fold desc="Git Project Init">
    currentpath = os.path.abspath(os.getcwd())

    os.chdir(repofullpath)
    os.system('git init')
    os.system('git add .')
    os.system("git commit -m 'Initial Commit' --allow-empty-message --allow-empty")

    if formdata.get('author', None) and formdata.get('repo', None):
        os.system('git remote add origin git@github.com:{author}/{repo}.git'.format(**formdata))
    else:
        logging.info("You did not input author and repo name. So your remote url is not set up.")

    req = requests.post(url='https://api.github.com/user/repos',
                        data=json.dumps({
                            'name': formdata['repo'],
                            'description': formdata.get('description', ''),
                            'homepage': 'https://www.github.com/%s/%s' % (
                                formdata.get('user', ''), formdata.get('repo', '')),
                            # 'gitignore_template': '',
                            # 'license_template': '',
                        }),
                        auth=HTTPBasicAuth(formdata.get('user', ''), os.environ['TOKEN']))

    try:
        if req.ok and 'id' in req.json():
            print("You've succesfully create repository on Github {0}".format(req.json()['html_url']))
        else:
            print json.dumps(req.json())
    except Exception, e:
        logging.exception(e)

    os.system("git push -u origin master")

    os.chdir(currentpath)
    # os.chdir(os.path.abspath(os.path.dirname(os.path.realpath(__file__))))

    # </editor-fold>

    # <editor-fold desc="Readme">
    readmecontent = """# {project}\n\n{description}\n
    """.format(**formdata)

    readmefile = "{0}/README.md".format(repofullpath)
    with open(readmefile, 'wb') as f:
        f.write(readmecontent)
        f.close()

    # </editor-fold>

    # <editor-fold desc="Gitignore">
    gitignore_content = open('packathon2016/data/ignore/{0}.gitignore'.format(formdata['ignore'])).read()

    with open("{0}/.gitignore".format(repofullpath), 'wb') as f:
        f.write(gitignore_content)
        f.close()

    # </editor-fold>

    # <editor-fold desc="LICENSE">
    license_content = open('packathon2016/data/licenses/{0}'.format(formdata['license'])).read()
    license_content = license_content \
        .replace('{project}', formdata['project']) \
        .replace('{year}', datetime.datetime.now().year.__str__()) \
        .replace('{owner}', formdata['author']) \
        .replace('{project}', formdata['project']) \
        .replace('{description}', formdata['description'])

    with open("{0}/LICENSE".format(repofullpath), 'wb') as f:
        f.write(license_content)
        f.close()
    # </editor-fold>

    pass

    if __name__ == '__main__':
        main()
