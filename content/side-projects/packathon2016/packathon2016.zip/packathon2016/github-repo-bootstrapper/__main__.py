#!/usr/bin/env python
# coding=utf-8
__author__ = u'Ahmed Şeref GÜNEYSU'

import ui

if __name__ == '__main__':
    ui.main()
