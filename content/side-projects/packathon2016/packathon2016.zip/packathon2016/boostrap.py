#!/usr/bin/env python
# coding=utf-8
import logging

__author__ = u'Ahmed Şeref GÜNEYSU'

import json
import requests
import os
import sys


def main(TIMEOUT=(5.0, 5.0)):
    licenses_json = open('packathon2016/data/licenses.json')
    ignore_json = open('packathon2016/data/ignore.json')

    licenses = json.loads(licenses_json.read())
    ignores = json.loads(ignore_json.read())

    if not os.path.exists('packathon2016/data/licenses/'):
        os.makedirs('packathon2016/data/licenses/')
    if not os.path.exists('packathon2016/data/ignore/'):
        os.makedirs('packathon2016/data/ignore/')

    headers = {'Accept': 'application/vnd.github.drax-preview+json'}

    for license in licenses:
        key, name, url = license['key'], license['name'], license['url']
        filename = "packathon2016/data/licenses/{0}".format(key)

        if os.path.exists(filename):
            continue

        data = requests.get(url=url, headers=headers, timeout=TIMEOUT).json()

        if 'message' in data:
            logging.exception(url)
            continue

        content = data['body'] \
            .replace("[project]", "{project}") \
            .replace("[year]", "{year}") \
            .replace("{yyyy}", "{year}") \
            .replace("<yyyy>", "{year}") \
            .replace("[fullname]", "{owner}") \
            .replace("{name of copyright owner}", "{owner}") \
            .replace("<name of author>", "{owner}") \
            .replace("[description]", "{description}") \
            .replace("{one line to give the program's name and a brief idea of what it does.}", "{description}") \
            .replace("<one line to give the program's name and a brief idea of what it does.>", "{description}")

        with open(filename, "wb") as f:
            f.write(content)

    for ignore in [e for e in ignores if e['type'] == 'file' and e['name'].endswith('.gitignore')]:
        name, url = ignore['name'], ignore['download_url']
        filename = "packathon2016/data/ignore/{0}".format(name)

        if os.path.exists(filename):
            continue

        data = requests.get(url, timeout=TIMEOUT)

        if 'message' in data:
            logging.exception(url)
            continue

        content = data.content
        with open(filename, "wb") as f:
            f.write(content)
            f.close()

        # Default .gitignore file
        with open("packathon2016/data/ignore/.gitignore", 'wb') as f:
            f.write('# Default Git ignore file')
            f.close()


if __name__ == '__main__':
    main()
