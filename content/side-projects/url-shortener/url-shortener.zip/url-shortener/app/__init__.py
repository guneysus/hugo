#!/usr/bin/env python
# coding:utf-8
import base64
import os
import logging

from urllib.parse import urlparse, urlunparse

import redis

r = redis.StrictRedis(host='redis')

invalid_chars = '-_.!?~/\\/!#$%^&**)_=Il1O0o'


def isurl(url):
    """
    1. Must be only http(s)
    2. Query parameters ? (I think it shoul be exists)
    3. Unicode domains [ok]
    :param url:
    :return:
    """

    parsed = urlparse(url.__str__())
    msg = "url: {2} netloc: {0} scheme: {1}".format(parsed.netloc, parsed.scheme, url.__str__())
    logging.debug(msg)

    return \
        '.' in parsed.netloc and \
        ':' not in parsed.netloc and \
        not parsed.netloc.endswith('.') and \
        parsed.scheme in ['http', 'https']



def normalize(url):
    parsed = urlparse(url)
    if parsed.scheme == '':
        data = [e if i > 0 else 'http' for i, e in enumerate(list(parsed[1:]))]
        data.extend([None])
        url = urlunparse(data)
    return url

def isavailable(key):
    return not r.exists(key)
    
def save(shortened_data):
    r.set(name=shortened_data['key'], value=shortened_data['url'])
    return shortened_data

def isvalid(text):
    """
    Checks if shortened text contains invalid characters
    :param text:
    :return:
    """
    return not any((c in invalid_chars) for c in text)


def random_alias(length=5):
    """
    Generates random shortened char-sets until does not contain invalid characters
    :return:
    """

    length = length if (length and isinstance(length, int)) else 10
    if length < 2:
        raise ValueError("Length must be great or equal to 2")
    step = 0
    text = invalid_chars
    n = int(((length / 4) + 1) * 3)
    while not isvalid(text):
        text = str(base64.urlsafe_b64encode(os.urandom(n)).lower()[:length])
        step += 1
        if step >= 10:
            return
            raise Exception("Maximum iteration limit 10 exceeded")

    return text

def shorten(url, length):
    url = normalize(url)
    if not isurl(url=url):
        raise Exception("%s is not a valid url" % url)
    alias = random_alias(length)
    isavailable(alias)
    return save(dict(key=alias, url=url))

