#!/usr/bin/env python
# coding:utf-8
import app
import timeit

N = 10000

t = timeit.Timer(
"""
app.random_alias(5)
""", setup='import app'
)

result = t.timeit()
print(result/N)