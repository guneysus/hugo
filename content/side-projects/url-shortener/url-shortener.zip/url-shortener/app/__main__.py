#!/usr/bin/env python
# coding:utf-8
"""
<TODO>
"""
import app

def main():
    """
    <TODO>
    """
    print (app.shorten('google.com', 5))


if __name__ == '__main__':
    main()
