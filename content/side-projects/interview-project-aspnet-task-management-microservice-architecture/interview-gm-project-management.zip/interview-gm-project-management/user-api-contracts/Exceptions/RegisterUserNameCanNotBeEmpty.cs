﻿using System;

namespace user_api_contracts.Exceptions
{
    public class RegisterUserNameCanNotBeEmpty : Exception { }
}
