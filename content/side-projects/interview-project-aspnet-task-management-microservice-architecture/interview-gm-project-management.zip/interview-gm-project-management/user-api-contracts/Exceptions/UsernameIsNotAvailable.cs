﻿using System;

namespace user_api_contracts.Exceptions
{
    public class UsernameIsNotAvailableException : Exception { }
    public class UserIsNotFoundException : Exception { }
}
