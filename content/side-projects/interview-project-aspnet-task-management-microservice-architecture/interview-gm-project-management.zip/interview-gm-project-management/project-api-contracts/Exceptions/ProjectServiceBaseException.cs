using System;

namespace project_api_contracts.Exceptions
{
  public class ProjectServiceBaseException : Exception {
    
  }
}