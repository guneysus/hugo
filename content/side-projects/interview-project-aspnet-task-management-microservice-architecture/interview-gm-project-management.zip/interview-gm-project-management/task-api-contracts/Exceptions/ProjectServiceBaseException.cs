using System;

namespace task_api_contracts.Exceptions
{
  public class TaskServiceBaseException : Exception {
    
  }
}