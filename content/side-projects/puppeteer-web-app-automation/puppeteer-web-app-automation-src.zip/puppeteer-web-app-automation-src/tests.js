const puppeteer = require("puppeteer");

const width = 1440;
const height = 960;

const LAUNCH_URL = "http://localhost:2016/tr/giris-yap";

const ShoppingCart = (function() {
  return {};
})();

(async () => {
  const browser = await puppeteer.launch({
    headless: false,
    slowMo: 200,
    devtools: false,
    defaultViewport: null,
    args: [
    `--window-size=${width},${height}`,
    "--profile-directory='Profile 2'"
    ],
    //executablePath: "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe"
  });

  const page = await browser.newPage();
  
  page.setDefaultNavigationTimeout(15000);

  await page.goto(LAUNCH_URL, { waitUntil: "networkidle2" });

  page.on("console", msg => console.log("PAGE LOG:", msg.text()));

  await page.setCookie(
    {
      name: "ASP.NET_SessionId",
      value: process.env.ASPNET_SESSION_ID,
      httpOnly: true
    },
    { name: "_ga", value: "GA1.1.945615172.1554736876" },
    { name: "_gid", value: "GA1.1.1524679325.1554736876" },

    { name: "_ga", value: "GA1.2.415353656.1554278723" },
    { name: "_gid", value: "GA1.2.1834585254.1554892849" }
  );

  // await page.goto("http://localhost:2016/tr/giris-yap", {
  //   waitUntil: "networkidle2"
  // });

  // await page.goto("http://localhost:2016/tr/urunler/gm8", {
  //   waitUntil: "networkidle2"
  // });

  // await page.click("#product-submenu > div > a.btn-orange.buy"); // GM8 sepete ekle sayfası
  // await page.click("#btn-2"); // siyah GM8
  //   await page.click("#92DB78773A4944B9"); // Çift SIM kart
  //   await page.click("#A56E7AC280448B0C"); // Tek SIM kart

  // await page
  //   .click(
  //     "body > form > section.model-select-view-box > div > div > div.col-md-6.col-xs-4.pull-right.model-select-price.model-select-view-m-right > div > button"
  //   )
  //   .catch(err => {
  //     console.error(err);
  //     throw err;
  //   }); // sepete ekle

  await page.goto("http://localhost:2016/tr/sepet/sepet-detayim", {
    waitUntil: "networkidle2"
  });

  // await page.goto("http://localhost:2016/tr/sepet/adreslerim", {
  //   waitUntil: "networkidle2"
  // });

  await page.goto("http://localhost:2016/tr/odeme-yap", {
    waitUntil: "networkidle2"
  });

  await page.click("#EC9692D38A9504F9");

  //await page.evaluate(async () => {
  //  $("#CreateOrder").click();
  //});
  
  await page.click('#CreateOrder', () => {
  
  });
  
  //await browser.close();
})();
