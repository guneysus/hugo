$env:ASPNET_SESSION_ID = "nmglobhbwrlxpulsniegne5s"

npm test