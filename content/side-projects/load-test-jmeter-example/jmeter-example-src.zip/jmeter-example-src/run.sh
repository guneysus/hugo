#!/bin/bash

set -ex

USERS=20000
DURATION=1800
RAMPUP_PERIOD=1200

REPORT_ID="${USERS}users_${DURATION}s_$(date +%Y-%m-%d_%H%M)"
RESULT_FILE="results/${REPORT_ID}.jtl"
RESULTS_FOLDER="results/${REPORT_ID}"

RESULT_HTML="${RESULTS_FOLDER}/index.html"

mkdir -p ${RESULTS_FOLDER}


jmeter.cmd \
    --nongui -t ip-to-location.jmx \
    -Jrampupperiod=${RAMPUP_PERIOD} \
    -Jusers=${USERS} \
    -Jduration=${DURATION} \
    -l ${RESULT_FILE} \
    -e \
    -o ${RESULTS_FOLDER}

start ${RESULT_HTML}

