/* HELLO WORLD SERVER */
// Load the http module to create an http server.
var http = require('http');
var hljs = require('./node_modules/highlight.js');

// Prism.plugins.autoloader.languages_path = 'node_modules/prism/components/';

var CODE = `
class Foo(object):
	def __init__(self, *args, **kwargs):
		super(Foo, self).__init__(*args, **kwargs)

@requires_authorization
def somefunc(param1='', param2=0):
    r'''A docstring'''
    if param1 > param2: # interesting
        print 'Greater'
    return (param2 - param1 + 1 + 0b10l) or None

class SomeClass:
    pass

>>> message = '''interpreter
... prompt''

`;
// var html = Prism.highlight(CODE, Prism.languages.javascript);
// var html = hljs.highlight("javascript", CODE).value;

// Configure our HTTP server to respond with Hello World to all requests.
var server = http.createServer(function(request, response) {
    response.writeHead(200, {
        "Content-Type": "text/html"
    });

    var head = `
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.2.0/styles/default.min.css">
	<!-- <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.2.0/styles/railscasts.min.css"> -->
	<!-- <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.2.0/styles/darkula.min.css">  -->
	<!-- <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.2.0/styles/androidstudio.min.css"> -->

</head>
<body>
`;


    var footer = `</body></html>`;

    response.write(head);
    response.write(`<pre><code class="python hljs">`);

    // response.write( hljs.highlight("python", CODE).value );
    response.write( hljs.highlightAuto(CODE).value );

	response.write(`</code></pre>`);
    response.end(footer);


});


// Listen on port 8000, IP defaults to 127.0.0.1
server.listen(8000);

// Put a friendly message on the terminal
console.log("Server running at http://127.0.0.1:8000/");