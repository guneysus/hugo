#!/usr/bin/env python
# coding: utf-8
import re

import markdown2
from flask import Flask
from pygments import highlight
# noinspection PyUnresolvedReferences
from pygments.formatters import HtmlFormatter
from pygments.lexers import (get_lexer_by_name,
                             get_lexer_for_filename,
                             get_lexer_for_mimetype)
from flask import request, send_from_directory

link_patterns = [(re.compile(
    r'((([A-Za-z]{3,9}:(?:\/\/)?)(?:[\-;:&=\+\$,\w]+@)?[A-Za-z0-9\.\-]+(:[0-9]+)?|(?:www\.|[\-;:&=\+\$,\w]+@)[A-Za-z0-9\.\-]+)((?:\/[\+~%\/\.\w\-_]*)?\??(?:[\-\+=&;%@\.\w_]*)#?(?:[\.\!\/\\\w]*))?)'),
                  r'\1')]

app = Flask(__name__, static_url_path='')

convertor = markdown2.MarkdownWithExtras(extras=[
    'code-friendly',
    'fenced-code-blocks',
    'tables',
    'smarty-pants',
    'spoiler',
    'footnotes',
    'header-ids',
    'link-patterns',
    'nofollow',
    'markdown-in-html',
],
    link_patterns=link_patterns
)

code = '''python
    def foo(object):
    pass
'''

content = '''
<div markdown='1'>
This is a **bold statement**.
</div>
$ markdown2 -x markdown-in-html foo.txt
<div>

<p>This is a <strong>bold statement</strong>.</p>

</div>

www.google.com

> This is a spoiler
> This is also


"Double quote"

'Single Quote'
 

# h1 header

## h2 header

### h3

*Italic* **BOLD** ~~strike~~ ~strike~ 

__DISABLED for code friendlines__


```python
def foo(object):
    pass
```

```javascript
var f = function(x, e, p){
    console.log(undefined);
}
```

| A | B | C |
| - | - | - |
| 1 | 2 | 3 |

- list
- list

0. Foo
* asdasd
+ adasd
- asdasd



'''

styles = '''
<!-- <link rel="stylesheet" type="text/css" href="http://127.0.0.1/pygments/monokai.css">
<link rel="stylesheet" type="text/css" href="css/monokai.css">
<link rel="stylesheet" type="text/css" href="css/friendly.css">
<link rel="stylesheet" type="text/css" href="css/tango.css">

-->

<link rel="stylesheet" type="text/css" href="css/github.css">

'''


@app.route('/css/<path:path>')
def send_css(path):
    return send_from_directory('css', path)


@app.route('/')
def index():
    return styles + convertor.convert(content)


@app.route('/render', methods=['POST'])
def render():
    content = request.form.get('content', '')
    return styles + convertor.convert(content)


@app.route('/renderfile', methods=['POST'])
def renderfile():
    content = request.files['README.md'].read()
    return styles + convertor.convert(content)


@app.route('/name')
def name():
    lexer = get_lexer_by_name("python", stripall=True)
    formatter = HtmlFormatter(linenos=True, cssclass="codehilite")
    result = highlight(code, lexer, formatter)
    return result


@app.route('/filename')
def filename():
    lexer = get_lexer_for_filename('spam.py', stripall=True)
    formatter = HtmlFormatter(linenos=True, cssclass="codehilite")
    result = highlight(code, lexer, formatter)
    return result


@app.route('/mime')
def mime():
    lexer = get_lexer_for_mimetype('text/x-perl', stripall=True)
    formatter = HtmlFormatter(linenos=True, cssclass="codehilite")
    result = highlight(code, lexer, formatter)
    return result


if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True, port=8000)
