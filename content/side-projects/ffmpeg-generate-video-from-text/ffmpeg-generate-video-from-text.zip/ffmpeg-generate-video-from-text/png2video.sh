#!/usr/bin/env bash

ffmpeg -loop 1 -i 480x720.png -t 33 -r 1 -c:v libx264 480x720.mp4
