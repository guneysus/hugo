#!/usr/bin/env python
# coding: utf-8
from __future__ import print_function

import subprocess

from converter import Converter

convertor = Converter()
import os


class Metadata(object):
    name = None
    inputfolder = None
    outputfolder = None

    def __init__(self, name, inputfolder, outputfolder, videoutputfolder):
        self.videoutputfolder = videoutputfolder
        self.outputfolder = outputfolder
        self.inputfolder = inputfolder
        self.name = name

    @property
    def barefile(self):
        return self.name.replace('.mp3', '')

    @property
    def probe(self):
        return convertor.probe(self.inputfile)

    @property
    def cuz(self):
        return int(self.name.split('_')[0])

    @property
    def sayfa(self):
        return int(self.name.replace('.mp3', '')[-3:])

    @property
    def hizb(self):
        return int(self.name.split('_')[1])

    @property
    def size(self):
        return os.stat(self.inputfile).st_size / 1024.0

    @property
    def duration(self):
        return self.probe.format.duration

    @property
    def inputfile(self):
        return os.path.join(self.inputfolder, self.name)

    @property
    def audio_output(self):
        return os.path.join(self.outputfolder, self.name)

    @property
    def video_output(self):
        return os.path.join(self.videoutputfolder, self.barefile + '.mp4')

    @property
    def text(self):
        template = u"""Fatih Çollak
{cuz}. Cüz
{sayfa}. Sayfa"""

        return template.format(cuz=self.cuz, sayfa=self.sayfa)


class CONFIG(object):
    # AUDIO_INPUT = u"/home/ahmed/Music/Fatih Çollak/30. Cüz"
    AUDIO_INPUT_FOLDER = u"/home/ahmed/Music/Fatih Çollak"

    AUDIO_OUTPUT = u"audio"
    VIDEO_OUTPUT = u"video"
    COMBINED = u"combined"

    PROFILE = {
        'format': 'mkv',
        'audio': {
            'codec': 'mp3',
            # 'samplerate': 22050,
            'bitrate': 64000.0,
            'channels': 2
        }}


def create_canvas():
    # noinspection PyUnusedLocal
    command = ["convert", "-size", "480x720", "xc:black", "canvas.png"]
    subprocess.call(command)


def test():
    pass


def combine(audio, video, output):
    args = ["ffmpeg", "-r", "1",
            "-i", audio,
            "-i", video,
            "-c:v", "copy", "-c:a", "mp3", "-strict",
            "experimental", output, "-y"
            ]
    subprocess.call(args=args)


def generate_combined_videos():
    for f in os.listdir(CONFIG.AUDIO_OUTPUT):
        fmeta = Metadata(
                name=f,
                inputfolder=CONFIG.AUDIO_INPUT_FOLDER,
                outputfolder=CONFIG.AUDIO_OUTPUT,
                videoutputfolder=CONFIG.VIDEO_OUTPUT)

        audio = os.path.join(CONFIG.AUDIO_OUTPUT, f)
        video = os.path.join(CONFIG.VIDEO_OUTPUT, fmeta.barefile + '.mp4')
        combined = os.path.join(CONFIG.COMBINED, fmeta.barefile + '.mp4')
        args = map(os.path.abspath, [audio, video, combined])
        combine(*args)


def generate_muted_videos():
    for _ in os.listdir(CONFIG.AUDIO_INPUT_FOLDER)[:]:
        folder = os.path.join(CONFIG.AUDIO_INPUT_FOLDER, _, )
        for filename in os.listdir(folder)[:]:
            meta = Metadata(
                name=filename,
                inputfolder=folder,
                outputfolder=CONFIG.AUDIO_OUTPUT,
                videoutputfolder=CONFIG.VIDEO_OUTPUT)
            generate_video(meta.duration, meta.video_output, meta.text)


def convert_audios():
    for c in os.listdir(CONFIG.AUDIO_INPUT_FOLDER)[:]:
        folder = os.path.join(CONFIG.AUDIO_INPUT_FOLDER, c, )
        for filename in os.listdir(folder)[:]:
            meta = Metadata(
                name=filename,
                inputfolder=folder,
                outputfolder=CONFIG.AUDIO_OUTPUT,
                videoutputfolder=CONFIG.VIDEO_OUTPUT)
            conversion = convertor.convert(meta.inputfile, meta.audio_output, CONFIG.PROFILE, timeout=1)
            for __ in conversion:
                print("%% %f" % __)


def generate_video(duration, output, text):
    args = ["sh", "generate_video.sh", str(duration), output, text]
    subprocess.call(args=args)


def generate_video_textfile(duration, output, text):
    """
    FIXME
    :param duration:
    :param output:
    :param text:
    :return:
    """
    raise NotImplemented("3 satırlık metnin 2den sonrasını yazmıyor")

    import tempfile
    import codecs
    tmp = tempfile.mktemp()
    with codecs.open(tmp, 'wb', encoding='utf-8') as f:
        f.write(text)
        args = ["sh", "generate_video_textfile.sh", str(duration), output, tmp]
        subprocess.call(args=args)
    os.remove(tmp)


if __name__ == '__main__':
    # convert_audios()
    # create_canvas()
    # generate_videos()
    # generate_muted_videos()
    generate_combined_videos()
