#!/usr/bin/env bash
# Usage:
# -----
$ sh generate_video.sh  {duration} {output_video} {text}

# sh generate_video.sh 3 test.mp4 "Ahmed Şeref"
#
ffmpeg -f lavfi -i color=c=black:s=480x720:d=$1 -vf \
"drawtext=\
    fontfile=fonts/Roboto-Condensed.ttf: \
    fontsize=22: \
    fontcolor=white:\
    x=(10):\
    y=(h-text_h-line_h):\
    boxborderw='0': \
    alpha='1.0':\
    text='$3':\
    box='0':" \
$2 -y
