# coding: utf-8
from setuptools import setup

setup(
    name='telemetry',
    version='1.0.0',
    packages=['telemetry'],
    url='',
    license='BSD-3-Clause',
    author=u'Ahmed Şeref GÜNEYSU',
    author_email='serefguneysu@gmail.com',
    description='',
    install_requires=[
        'tornado',
        'pandas'
    ]
)
