#!/usr/bin/env python

from __future__ import print_function
from __future__ import print_function

import socket

TCP_IP = '192.168.1.22'
TCP_PORT = 3400
BUFFER_SIZE = 1024  # Normally 1024, but we want fast response

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((TCP_IP, TCP_PORT))
s.listen(16 * 1024)

conn, addr = s.accept()
print('Connection address:', addr)

try:
    while 1:
        try:
            data = conn.recv(BUFFER_SIZE)
        except socket.error as e:
            if e.strerror == 'Connection reset by peer':
                pass
            else:
                raise
        if not data:
            break
            # continue
        else:
            print(data)
        try:
            conn.send(data)  # echo
        except socket.error as e:
            if e.strerror == 'Broken pipe' or e.strerror == 'Connection reset by peer':
                pass
            else:
                raise
except KeyboardInterrupt:
    conn.close()
    print("exited cleanly")
