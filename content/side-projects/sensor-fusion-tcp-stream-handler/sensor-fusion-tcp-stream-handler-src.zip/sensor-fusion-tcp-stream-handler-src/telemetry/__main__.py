#!/usr/bin/env python
# coding: utf-8
from  __future__ import print_function

from collections import deque, namedtuple

import geopy.distance
import tornado.tcpserver
from rx import Observable, Observer
from tornado.gen import coroutine
from tornado.ioloop import IOLoop

Coordinate = namedtuple('Coordinate', ['ts', 'lat', 'lon', 'v_kmh', 'v_ms'])


class SensorDataObserver(Observer):
    coords = deque([])

    def on_completed(self):
        print("Done!")

    @staticmethod
    def point(i):
        return SensorDataObserver.coords[i]

    def on_next(self, data):
        raw = data.strip().split()

        ts, lat, lon, alt = [float(raw[0])] + map(float, raw[2:])
        _dx = lambda p1, p0: geopy.distance.vincenty((p1[0], p1[1]), (p0[0], p0[1]))

        dx, dt, v_kmh, v_ms = 0, 0, 0, 0

        if len(self.coords) >= 1:
            p1 = self.point(-1)
            dx, dt = _dx((p1.lat, p1.lon), (lat, lon)), ts - p1.ts
            v_kmh = dx.kilometers / (dt / 1000.0 / 60.0 / 60)
            v_ms = dx.meters / (dt / 1000.0)

        coord = Coordinate(*[ts, lat, lon, v_kmh, v_ms])
        self.coords.append(coord)

        print(coord)

    def on_error(self, error):
        print("Error Occurred: {0}".format(error))


class TcpConnection(Observable):
    # noinspection PyAttributeOutsideInit
    def subscribe(self, observer):
        self.observer = observer

    def __init__(self, stream, address):
        self._stream = stream
        self._address = address
        self._stream.set_close_callback(self.on_close)
        self.read_message()
        self.observer = None

    def read_message(self):
        self._stream.read_until('\n', self.handle_message)

    def handle_message(self, data):
        if self.observer:
            self.observer.on_next(data)

        self.read_message()

    def on_close(self):
        print("the monitored %d has left", self._address)


class Server(tornado.tcpserver.TCPServer):
    @coroutine
    def handle_stream(self, stream, address):
        print("new connection", address, stream)
        source = TcpConnection(stream, address)
        source.subscribe(SensorDataObserver())

        # gps = source.filter(lambda x: x['type'] == 'ORI').map(lambda x: x)
        # gps.subscribe(lambda: print(x))


def main():
    server = Server()
    server.bind(port=3400, address='0.0.0.0')
    server.start(num_processes=1)
    IOLoop.current().start()


if __name__ == '__main__':
    main()
