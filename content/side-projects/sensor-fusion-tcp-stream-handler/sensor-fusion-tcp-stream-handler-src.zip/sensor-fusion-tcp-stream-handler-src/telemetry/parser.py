#!/usr/bin/env python
# coding:utf-8
from __future__ import print_function

import csv

with open("data/9e98c056a5c0a44c_20170214T132531.txt") as tsv:
    for line in csv.reader(tsv, dialect="excel-tab"):  # You can also use delimiter="\t" rather than giving a dialect.
        print(line)
