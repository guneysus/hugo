from setuptools import setup

setup(
    name='youtube-downloader',
    version='',
    packages=[''],
    url='',
    license='',
    author='Ahmed Seref Guneysu',
    author_email='',
    description='',
    requires=['tornado', 'youtube_dl']
)
