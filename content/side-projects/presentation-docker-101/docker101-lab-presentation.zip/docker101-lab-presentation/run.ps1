# /usr/share/nginx/html

docker rm web8002; echo ""
docker run --rm -p 8002:80  -v "C:\Users\ahmed.guneysu\Documents\ahmed.guneysu@generalmobile.com\sunumlarim\docker-101-lab\img:/usr/share/nginx/html/img/" -d --name web8002 nginx:1.17 

docker exec -it web8002 bash -c "ls /usr/share/nginx/html/img/"

start http://localhost:8002/img/powershell_cQ6UZMRyyp.png