---
title: "`docker 101`"
revealjs-url: 'presentation'
slideNumber: true
hash: true
fragmentInURL: true
transition: 'fade'
transitionSpeed: 'fast'
backgroundTransition: 'slide'
center: false
---


## `kurulum`

[docker/install](https://docs.docker.com/install/)

---


## `sistem gerekisinimleri`

Windows 10 64-bit: **Pro, Enterprise**, or Education (Build 15063 or later).

**Hyper-V** and Containers Windows özelliği.

Hyper-V destekleyen bir anakart veya işletim sisteminiz yoksa herhangi bir Linux türevi
kurup sıradan bir bilgisayarda Docker'ı rahatlıkla kullanabilirsiniz.

---

## `{}`

```shell
> docker --version
Docker version 19.03.2, build 6a30dfc

```

---

### `docker desktop for windows`

![Docker Desktop for Windows](img/Docker_Desktop_9HopFXwOva.png)


---


## `kurulumun testi`

```shell
> docker run hello-world
Unable to find image 'hello-world:latest' locally
latest: Pulling from library/hello-world
1b930d010525: Already exists
Digest: sha256:b8ba256769a0ac28dd126d584e0a2011cd2877f3f76e093a7ae560f2a5301c00
Status: Downloaded newer image for hello-world:latest

Hello from Docker!
```

---

## `neler oluyor?`

[hub.docker.com/_/hello-world](https://hub.docker.com/_/hello-world?tab=tags)

![hello world docker hub](img/opera_RQew3Ms3Xj.png)


---

## `docker images`

```shell
>  docker image ls
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
hello-world         latest              fce289e99eb9        8 months ago        1.84kB
```

---

## `docker containers`

```shell
> docker container ls --all
CONTAINER ID        IMAGE               COMMAND             CREATED              STATUS                      PORTS               NAMES
e020a05d4d8a        hello-world         "/hello"            About a minute ago   Exited (0) 59 seconds ago                       competent_gagarin
```

---

## `neler oluyor ?`

![](img/bMyAWovoha.png)

---

## `uygulamaya bağlanalım`

```shell
> docker run --interactive --tty ubuntu bash
Unable to find image 'ubuntu:latest' locally
latest: Pulling from library/ubuntu
35c102085707: Downloading [==========>                                        ]  5.545MB/26.69MB
251f5509d51d: Download complete
8e829fe70a46: Download complete
6001e1789921: Download complete
Digest: sha256:d1d454df0f579c6be4d8161d227462d69e163a8ff9d20a847533989cf0c94d90
Status: Downloaded newer image for ubuntu:latest
root@44b5398ccff4:/# ls /
bin  boot  dev  etc  home  lib  lib64  media  mnt  opt  proc  root  run  sbin  srv  sys  tmp  usr  var
```

---

## `nginx with docker`

```
docker run --detach --publish 80:80 --name webserver nginx
```

![nginx with docker](img/powershell_cQ6UZMRyyp.png)


---

## `nginx with docker`

![nginx with docker](img/opera_gTpuslWGBj.png)