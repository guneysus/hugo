<script>
import axios from "axios";
import store from "../store";
import { mapState } from "vuex";
import swal from "sweetalert";

export default {
  store,
  name: "Login",

  methods: {
    submit: function() {
      var self = this;

      axios
        .post(self.api + "/api/account/login", {
          username: self.username,
          password: self.password
        })
        .then(function(r) {
          var token = r.data;
          axios
            .post(
              self.api + "/api/account/info",
              {},
              {
                headers: {
                  Authorization: "Bearer " + token
                },
                params: {}
              }
            )
            .then(r => {
                var me = r.data;
                store.commit('setMe', me);
            })
            .catch(err => {
              throw err;
            });
          store.commit("setToken", token);
          //   swal("Success!", "You have successfully logged in!", "success");
          self.$router.push({
            name: "messages-home"
          });
        })
        .catch(err => {
          throw err;
        });
    }
  },
  data: function() {
    return {
      username: "",
      password: ""
    };
  },
  computed: mapState({
    api: "api",
    disableSubmitButton: function() {
      return this.password == "" || this.username == "";
    }
  })
};
</script>


<template>
  <section class="section">
    <h1 class="title">Login</h1>
    <!-- <h2 class="subtitle">
        A simple container to divide your page into <strong>sections</strong>, like the one you're currently reading
    </h2> -->

    <div class="field is-horizontal">
        <div class="control">
            <p class="control has-icons-left">
                <input v-model="username" class="input is-rounded is-medium" type="text" placeholder="Username" maxlength="20">

                <span class="icon is-left">
                    <i class="fas fa-user"></i>
                </span>                    
            </p>
        </div>

    </div>

    <div class="field is-horizontal">
        <div class="control">
            <p class="control has-icons-left">
                <input v-model="password" class="input is-rounded is-medium " type="password" placeholder="Password" maxlength="20">
                <span class="icon is-small is-left">
                    <i class="fas fa-lock"></i>
                </span>                
            </p>
        </div>
    </div>

    <div class="field is-grouped">
    <div class="control">
        <button class="button is-success" @click=submit :disabled="disableSubmitButton">Submit</button>
    </div>
    </div>    

  </section>
</template>

<style>
</style>
