<script>
export default {};
</script>

<template>
    <div class="section">
        <router-link :to="{ name: 'messages', params: { username: 'ahmed' } }" class="button is-primary">Chat with Ahmed</router-link>
        <router-link :to="{ name: 'messages', params: { username: 'mehmet' } }" class="button is-primary">Chat with Mehmet</router-link>        
    </div>
</template>
