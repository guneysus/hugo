<script>
import axios from "axios";
import store from "../store";
import { mapState } from "vuex";
import swal from "sweetalert";

export default {
  store,
  name: "Register",
  data: function() {
    return {
      username: "",
      password_first: "",
      password_confirm: ""
    };
  },
  computed: mapState({
    api: "api",
    disableSubmitButton: function() {
      return (
        this.passwordsDoesNotMatch || this.password == "" || this.username == ""
      );
    },

    passwordsDoesNotMatch: function() {
      return this.password_first != this.password_confirm;
    },
    password: function() {
      if (this.passwordsDoesNotMatch) {
        return null;
      }
      return this.password_first;
    }
  }),
  methods: {
    submit: function() {
      var self = this;

      axios
        .post(self.api + "/api/account/register", {
          username: self.username,
          password: self.password
        })
        .then(function(r) {
          swal("Success!", "You have successfully registered!", "success");

          axios
            .post(self.api + "/api/account/login", {
              username: self.username,
              password: self.password
            })
            .then(function(r) {
              store.commit("setToken", r.data);
              swal("Success!", "You have successfully logged in!", "success");
              self.$router.push("messages");
            });
        })
        .catch(err => {
          swal("Error!", err.toString(), "error");
          throw err;
        });
    }
  }
};
</script>

<template>
  <section class="section">
    <h1 class="title">Register</h1>
    <!-- <h2 class="subtitle">
        A simple container to divide your page into <strong>sections</strong>, like the one you're currently reading
    </h2> -->

    <div class="field is-horizontal">
        <div class="control">
            <p class="control has-icons-left">
                <input v-model="username" class="input is-rounded is-medium" type="text" placeholder="Username" maxlength="20">
                <input v-model="password" type="hidden">

                <span class="icon is-small is-left">
                    <i class="fas fa-user"></i>
                </span>                    
            </p>
        </div>

    </div>

    <div class="field is-horizontal">
        <div class="control">
            <p class="control has-icons-left">
                <input v-model="password_first" class="input is-rounded is-medium " v-bind:class="{'is-danger': passwordsDoesNotMatch}" type="password" placeholder="Password" maxlength="20">
                <span class="icon is-small is-left">
                    <i class="fas fa-lock"></i>
                </span>                
            </p>
        </div>
    </div>

    <div class="field is-horizontal">
        <div class="control">
            <p class="control has-icons-left">
                <input v-model="password_confirm" class="input is-rounded is-medium"  v-bind:class="{'is-danger': passwordsDoesNotMatch}" type="password" placeholder="Confirm password" maxlength="20">
                <span class="icon is-small is-left">
                    <i class="fas fa-lock"></i>
                </span>
            </p>       
        <p v-if="passwordsDoesNotMatch" class="help is-danger">Passwords does  not match</p>

        </div>

    </div>

    <div class="field is-grouped">
    <div class="control">
        <button class="button is-success" @click=submit :disabled="disableSubmitButton">Submit</button>
    </div>
    </div>    

  </section>
</template>
