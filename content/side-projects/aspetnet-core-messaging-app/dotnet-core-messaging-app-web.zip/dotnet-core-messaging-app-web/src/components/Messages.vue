<script>
import store from "../store";
import { mapState } from "vuex";
import axios from "axios";
import * as moment from "moment";
import * as _ from "lodash";
import Vue from "vue";

Vue.filter("timeago", function(value) {
  return moment(value).fromNow();
});

export default {
  store,

  name: "Messages",

  data: function() {
    return {
      messages: [],
      messageBody: ""
    };
  },

  methods: {
    fetchMessages() {
    var self = this;

    axios
      .post(
        self.api + "/api/message/getconversation",
        {
          with: this.username
        },
        {
          headers: {
            Authorization: "Bearer " + self.token
          },
          params: {}
        }
      )
      .then(r => {
        var messages = _.reverse(r.data.messages);
        self.messages = messages;

        store.commit("setMessages", {
          messages: messages,
          username: self.username
        });
      })
      .catch(err => {
        swal("Error!", err.toString(), "error");
        throw err;
      });
    },
    sendMessage() {
      var self = this;

      axios
        .post(
          self.api + "/api/message/send",
          {
            to: self.username,
            body: self.messageBody
          },
          {
            headers: {
              Authorization: "Bearer " + self.token
            }
          }
        )
        .then(r => {
          self.fetchMessages();
          self.messageBody = "";
        })
        .catch(err => {
          swal("Error!", err.toString(), "error");
          throw err;
        });
    }
  },
  computed: mapState({
    token: "token",
    api: "api",
    me: "me",
    username: function() {
      return this.$route.params.username;
    }
  }),

  created() {
    this.fetchMessages();
  }
};
</script>

<template>
<div>
    <h1>Messages with: {{ $route.params.username }} </h1>
  

<div class="field">
  <div class="control">
      <textarea 
        class="textarea" 
        v-model="messageBody"
        @keyup.13="sendMessage"
        placeholder="Type message and hit enter"></textarea>
    
  </div>
</div>


    <div v-if="messages" v-for="message in messages" class="box" v-bind:class="{  'has-background-light': message.from != me}">
      
      <article class="media">
        <div class="media-left ">
          <figure class="image is-64x64 is-pulled-right">
            <img src="https://bulma.io/images/placeholders/128x128.png" alt="Image">
          </figure>
        </div>

        <div class="media-content ">
          <div class="content ">
            <p>
              <small>{{message.id}}</small>
              <strong>{{message.from}}</strong> 
              <small>{{ message.sendDate | timeago }}</small>
              <br>
              {{ message.body }}
            </p>
          </div>
        </div>

      </article>
    </div>
        
</div>
</template>

<style>
</style>
