import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)


const store = new Vuex.Store({
    state: {
        me: null,
        token: null,
        api: 'http://ec2-54-67-108-121.us-west-1.compute.amazonaws.com',
        messages: {

        }
    },

    mutations: {
        setMe(state, me) {
            state.me = me;
        },
        setToken(state, token) {
            state.token = token;
        },
        setMessages(state, payload) {
            state.messages[payload.username] = payload.messages;
        }
    },

    getters: {
        api: state => {
            return state.api
        },
        messages: (state) => (username) => {
            return state.messages[username];
        }
    }

});


export default store;