<script>
import store from './store'
import { mapState } from 'vuex'

export default {
  store,
  name: 'App',
  computed: mapState({
    api: state => state.api
  })
}
</script>

<template>

<section class="section">
 
  <div class="container">

  <nav class="navbar" role="navigation" aria-label="main navigation">
    <div class="navbar-brand">
      <!-- <a class="navbar-item" href="/">
        <img src="https://bulma.io/images/bulma-logo.png" width="112" height="28">
      </a> -->

      <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
        <span aria-hidden="true"></span>
        <span aria-hidden="true"></span>
        <span aria-hidden="true"></span>
      </a>
    </div>

    <div id="navbarBasicExample" class="navbar-menu">
      <div class="navbar-start">
       
        <router-link :to="{ name: 'home'}" class="navbar-item" >Home</router-link>
        <router-link :to="{ name: 'messages-home' }" class="navbar-item" >Messages</router-link>
      </div>

      <div class="navbar-end">
        <div class="navbar-item">
          <div class="buttons">
            <router-link :to="{ name: 'register'}" class="button is-primary"><strong>Register</strong></router-link>
            <router-link :to="{ name: 'login'}" class="button is-light">Login</router-link>
          </div>
        </div>
      </div>
    </div>
  </nav>

  <router-view></router-view>

    <div class="field">
        <div class="control">
            <p class="control has-icons-left">
                <input v-model="api" class="input" type="text" readonly>

                <span class="icon is-small is-left">
                    <i class="fab fa-aws"></i>
                </span>                    
            </p>
        </div>

    </div>


  </div>
</section>

</template>



<style>

</style>
