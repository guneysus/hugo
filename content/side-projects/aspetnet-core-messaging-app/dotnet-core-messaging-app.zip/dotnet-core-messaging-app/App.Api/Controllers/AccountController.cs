﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using App.Contracts.Service;
using App.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Authentication;
using System.Threading.Tasks;
using System.Security.Principal;
using System.Collections.Generic;

namespace App.Api.Controllers
{
    [Route("api/[controller]/[action]")]
    public class AccountController : Controller
    {
        private readonly IAccountService accountService;
        private readonly IJWTService jwt;
        private readonly IConfiguration config;
        private readonly AuthHelper authHelper;
        private readonly IUserService userService;
        private readonly HttpContext context;

        public AccountController(IAccountService accountService,
            IJWTService jwt,
            IConfiguration config,
            AuthHelper authHelper,
            IUserService userService)
        {
            this.accountService = accountService;
            this.jwt = jwt;
            this.config = config;
            this.authHelper = authHelper;
            this.userService = userService;
        }

        [HttpPost]
        public IActionResult Register([FromBody]UserRegisterModel model)
        {
            accountService.Register(model);
            return Ok();
        }

        [HttpPost]
        public IActionResult Login([FromBody]UserLoginModel model)
        {
            var resp = accountService.Login(model);
            return Ok(resp);
        }

        [HttpPost, Authorize]
        public async Task<string> Info()
        {
            AuthenticateResult authenticateResult = await authHelper.GetAuthAsync();
            return await authHelper.GetUsernameAsync();
        }

        [HttpPost, Authorize]
        public IActionResult Block([FromBody]BlockUserModel model)
        {
            var token = authHelper.GetToken();
            userService.BlockUser(token, model.Username);
            return Ok();
        }
    }
}
