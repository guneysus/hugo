﻿using App.Contracts.Service;
using App.Models;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace App.Api.Controllers
{
    [Route("api/[controller]/[action]"), Authorize]

    public class MessageController : Controller
    {
        private readonly AuthHelper authHelper;
        private readonly IMessageService messageService;
        private readonly IMapper mapper;

        public MessageController(AuthHelper authHelper, IMessageService messageService, IMapper mapper)
        {
            this.authHelper = authHelper;
            this.messageService = messageService;
            this.mapper = mapper;
        }

        [HttpPost]
        public IActionResult Send([FromBody]SendMessageModel model)
        {
            messageService.SendMessage(
                token: authHelper.GetToken(),
                toUsername: model.To,
                body: model.Body);

            return Ok();
        }

        [HttpPost]
        public ConversationViewModel GetConversation([FromBody]GetConversationModel model)
        {
            var response = new ConversationViewModel();
            var messages = messageService.GetConversation(authHelper.GetToken(), model.With);
            response.Messages = mapper.Map<IList<MessageViewModel>>(messages);

            return response;
        }
    }
}
