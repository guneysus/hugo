using System.Data;
using System.Data.SQLite;
using System.Text;
using App.Api.Controllers;
using App.Contracts.Service;
using App.Contracts.Store;
using App.Service;
using App.Store;
using AutoMapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Serialization;

namespace App.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddTransient<IUserStore, UserStore>();
            services.AddTransient<IMessageStore, MessageStore>();
            services.AddTransient<IUserBlockStore, UserBlockStore>();
            services.AddTransient<DB>();

            services.AddTransient<IUserService, UserService>();
            services.AddTransient<IAccountService, AccountService>();
            services.AddTransient<IMessageService, MessageService>();


            //DB_FILE = $"{Guid.NewGuid().ToString().ToLower()}.sqlite3";

            services.AddTransient<IDbConnection, SQLiteConnection>(x => new SQLiteConnection("Data Source=db.sqlite3;Version=3;"));

            var mapperConfiguration = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(profile: new AutoMapperDefaultProfile("ProjectAutoMapperProfile"));
            });

            services.AddSingleton(mapperConfiguration.CreateMapper());

            services.AddTransient<IJWTService, JWTService>();

            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder.AllowAnyOrigin()
                      .AllowAnyMethod()
                      .AllowAnyHeader()
                      .AllowCredentials()
                .Build());
            });

            //services.AddMvc();

            services.AddMvcCore().AddJsonFormatters(options => options.ContractResolver = new CamelCasePropertyNamesContractResolver());

            services.AddAuthentication(o =>
            {
                o.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                o.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(options =>
            {

                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = Configuration["Jwt:Issuer"],
                    ValidAudience = Configuration["Jwt:Issuer"],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:Key"]))
                };
            });

            services.AddAuthorization();

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.AddScoped<AuthHelper>();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                //app.UseBrowserLink();
                //app.UseDeveloperExceptionPage();
            }
            else
            {
                //app.UseExceptionHandler("/Error");
            }

            app.UseCors("CorsPolicy");

            app.UseStaticFiles();

            app.UseMvc();

            app.UseAuthentication();
        }
    }
}
