﻿using App.Contracts.Service;
using Xunit;
using Microsoft.Extensions.DependencyInjection;
using App.Models;
using App.Contracts.Exceptions;

namespace App.Test.Message
{
    public class DirectMessageTests : BaseTest
    {
        public DirectMessageTests(DbFixture fixture) : base(fixture)
        {
        }

        [Fact]
        public void send_message_success()
        {
            var account = _serviceProvider.GetService<IAccountService>();
            var jwt = _serviceProvider.GetService<IJWTService>();
            var message = _serviceProvider.GetService<IMessageService>();

            UserRegisterModel user = new UserRegisterModel()
            {
                Username = "ahmed",
                Password = "123"
            };

            account.Register(user);

            account.Register(new UserRegisterModel()
            {
                Username = "mehmet",
                Password = "123"
            });

            var ahmedToken = account.Login(new UserLoginModel()
            {
                Username = "ahmed",
                Password = "123"
            });

            var mehmetToken = account.Login(new UserLoginModel()
            {
                Username = "mehmet",
                Password = "123"
            });

            message.SendMessage(token: ahmedToken, toUsername: "mehmet", body: "Merhaba Mehmet.");
            message.SendMessage(token: mehmetToken, toUsername: "ahmed", body: "Merhaba Ahmed.");
            message.SendMessage(token: ahmedToken, toUsername: "mehmet", body: "Nasılsın Mehmet?");
            message.SendMessage(token: mehmetToken, toUsername: "ahmed", body: "İyiyim Ahmed. Sen nasılsın Ahmed?");
        }

        [Fact]
        public void send_message_throw_error_on_blocked()
        {
            var accountService = _serviceProvider.GetService<IAccountService>();
            var userService = _serviceProvider.GetService<IUserService>();

            var jwtService = _serviceProvider.GetService<IJWTService>();
            var messageService = _serviceProvider.GetService<IMessageService>();

            UserRegisterModel userRegisterModel = new UserRegisterModel()
            {
                Username = "ahmed",
                Password = "123"
            };

            accountService.Register(userRegisterModel);

            accountService.Register(new UserRegisterModel()
            {
                Username = "mehmet",
                Password = "123"
            });

            var ahmedToken = accountService.Login(new UserLoginModel()
            {
                Username = "ahmed",
                Password = "123"
            });

            var mehmetToken = accountService.Login(new UserLoginModel()
            {
                Username = "mehmet",
                Password = "123"
            });

            userService.BlockUser(ahmedToken, "mehmet"); // Ahmed blocked the User mehmet

            Assert.Throws<YouAreBlockedSendingMessageToUserException>(() =>
            {
                messageService.SendMessage(token: mehmetToken, toUsername: "ahmed", body: "Merhaba Ahmed");
            });

        }

        [Fact]
        public void sending_message_to_a_non_existing_user_should_throw()
        {
            var account = _serviceProvider.GetService<IAccountService>();
            var jwt = _serviceProvider.GetService<IJWTService>();
            var message = _serviceProvider.GetService<IMessageService>();

            UserRegisterModel user = new UserRegisterModel()
            {
                Username = "ahmed",
                Password = "123"
            };

            account.Register(user);

            var token = account.Login(new UserLoginModel()
            {
                Username = user.Username,
                Password = user.Password
            });

            Assert.Throws<UserIsNotFoundException>(() =>
            {
                message.SendMessage(token, "non_existing_user_name", "Hello black hole...");
            });
        }
    }
}
