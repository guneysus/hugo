﻿using System;
using System.Data;
using System.IO;
using App.Store;
using Xunit;
using Microsoft.Extensions.DependencyInjection;
using AutoMapper;

namespace App.Test
{
    public class BaseTest : IClassFixture<DbFixture>, IDisposable
    {

        protected IServiceProvider _serviceProvider;
        protected readonly DB Db;
        protected readonly IMapper mapper;
        protected IDbConnection conn;
        private DbFixture fixture;

        public BaseTest(DbFixture fixture)
        {
            _serviceProvider = fixture.ServiceProvider;
            Db = _serviceProvider.GetService<DB>();

            mapper = _serviceProvider.GetService<IMapper>();
            conn = _serviceProvider.GetRequiredService<IDbConnection>();
            this.fixture = fixture;
        }

        public BaseTest()
        {
            Db.Users.CreateTableIfNotExists(conn);
            Db.BlockedUsers.CreateTableIfNotExists(conn);
            Db.Messages.CreateTableIfNotExists(conn);
        }


        public void Dispose()
        {
            File.Delete(fixture.DB_FILE);
        }
    }
}
