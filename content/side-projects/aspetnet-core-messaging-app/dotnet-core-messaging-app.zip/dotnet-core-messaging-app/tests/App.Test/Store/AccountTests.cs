﻿using System.Data;
using System.Data.SQLite;
using Xunit;

namespace App.Test.Store
{
    public class AccountTests : BaseTest
    {
        public AccountTests(DbFixture fixture) : base(fixture)
        {
        }

        [Fact]
        public void user_register()
        {
            var conn = GetConnection();

            Db.Users.Save(conn, new Contracts.Entities.User()
            {
                Username = "ahmed",
                Password = "123",
            });
        }

        [Fact]
        public void same_user_name_cannot_register()
        {
            var conn = GetConnection();

            var user1 = new Contracts.Entities.User()
            {
                Username = "ahmed",
                Password = "123",
            };


            var user2 = new Contracts.Entities.User()
            {
                Username = "ahmed",
                Password = "00000",
            };


            Db.Users.Save(conn, user1);

            Assert.Throws<SQLiteException>(() =>
            {
                Db.Users.Save(conn, user2);
            })
            ;
        }

        private IDbConnection GetConnection()
        {
            return base.conn;
        }
    }
}
