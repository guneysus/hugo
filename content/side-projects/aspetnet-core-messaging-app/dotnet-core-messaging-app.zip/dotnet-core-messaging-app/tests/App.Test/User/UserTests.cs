﻿using Xunit;

namespace App.Test.User
{
    public class UserTests : BaseTest
    {
        public UserTests(DbFixture fixture) : base(fixture)
        {
        }

        [Fact]
        public void block_should_not_block_itself() => Assert.True(false);

        [Fact]
        public void block_should_not_block_non_existing_user() => Assert.True(false);

        [Fact]
        public void block_success() => Assert.True(false);

        [Fact]
        public void unlock_success() => Assert.True(false);
    }
}
