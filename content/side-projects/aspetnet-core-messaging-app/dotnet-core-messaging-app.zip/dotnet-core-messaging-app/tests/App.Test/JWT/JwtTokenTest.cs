﻿using JWT;
using Xunit;
using Microsoft.Extensions.DependencyInjection;
using App.Contracts.Service;

namespace App.Test.JWT
{
    public class JwtTokenTests : BaseTest
    {
        private readonly IJWTService jwt;

        public JwtTokenTests(DbFixture fixture) : base(fixture)
        {
            jwt = fixture.ServiceProvider.GetService<IJWTService>();
        }

        [Fact]
        public void should_generate_token()
        {
            var token = jwt.Encode("ahmed");

            Assert.NotSame(string.Empty, token);
        }


        [Fact]
        public void should_decode_token()
        {
            var token = jwt.Encode("ahmed");

            try
            {

                var loginResponseModel = jwt.Decode(token);

                Assert.Equal(expected: "ahmed", actual: loginResponseModel.Username);

            }
            catch (TokenExpiredException)
            {
                throw;
            }
            catch (SignatureVerificationException)
            {
                throw;
            }
        }
    }
}
