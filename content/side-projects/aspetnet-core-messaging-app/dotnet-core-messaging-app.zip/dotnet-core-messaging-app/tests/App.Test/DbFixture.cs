﻿using System;
using System.Data;
using System.Data.SQLite;
using App.Contracts.Service;
using App.Contracts.Store;
using App.Service;
using App.Store;
using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace App.Test
{
    public class DbFixture
    {
        public string DB_FILE { get; }
        public string CONNECTION_STRING { get; }

        public DbFixture()
        {
            var services = new ServiceCollection();
            //serviceCollection
            //    .AddDbContext<SomeContext>(options => options.UseSqlServer("connection string"),
            //        ServiceLifetime.Transient);

            services.AddTransient<IUserStore, UserStore>();
            services.AddTransient<IMessageStore, MessageStore>();
            services.AddTransient<IUserBlockStore, UserBlockStore>();
            services.AddTransient<DB>();

            services.AddTransient<IUserService, UserService>();
            services.AddTransient<IAccountService, AccountService>();
            services.AddTransient<IMessageService, MessageService>();

            #region IConfiguration
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder();
            configurationBuilder.AddJsonFile("appsettings.json");
            services.AddTransient<IConfiguration>(x => configurationBuilder.Build());
            #endregion

            DB_FILE = $"{Guid.NewGuid().ToString().ToLower()}.sqlite3";

            var conn = new SQLiteConnection($"Data Source={DB_FILE};Version=3;");

            services.AddTransient<IDbConnection, SQLiteConnection>(x => conn);

            var mapperConfiguration = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(profile: new AutoMapperDefaultProfile("ProjectAutoMapperProfile"));
            });

            services.AddSingleton(mapperConfiguration.CreateMapper());

            services.AddTransient<IJWTService, JWTService>();

            ServiceProvider = services.BuildServiceProvider();


        }

        public IServiceProvider ServiceProvider { get; private set; }

    }
}
