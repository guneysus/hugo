﻿using App.Contracts.Service;
using App.Contracts.Store;
using AutoMapper;
using System.Data;

namespace App.Service
{
    public class UserService : IUserService
    {
        private readonly IUserStore userStore;
        private readonly IUserBlockStore userBlockStore;
        private readonly IDbConnection conn;
        private readonly IMapper mapper;
        private readonly IJWTService jwt;

        public UserService(
            IUserStore userStore,
            IUserBlockStore userBlockStore,
            IDbConnection conn,
            IMapper mapper,
            IJWTService jwt)
        {
            this.userStore = userStore;
            this.userBlockStore = userBlockStore;
            this.conn = conn;
            this.mapper = mapper;
            this.jwt = jwt;
        }

        void IUserService.BlockUser(string token, string username)
        {
            var me = jwt.Decode(token).Username;

            userBlockStore.Save(conn, new Contracts.Entities.UserBlock()
            {
                User = me,
                BlockedUser = username
            });
        }
    }
}
