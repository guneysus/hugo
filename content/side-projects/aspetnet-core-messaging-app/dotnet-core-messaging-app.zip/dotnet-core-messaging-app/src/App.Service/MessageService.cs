﻿using App.Contracts.Entities;
using App.Contracts.Exceptions;
using App.Contracts.Service;
using App.Contracts.Store;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Data;

namespace App.Service
{
    public class MessageService : IMessageService
    {
        private readonly IMessageStore messageStore;
        private readonly IUserBlockStore userBlockStore;
        private readonly IJWTService jwt;
        private readonly IMessageService self;
        private readonly IUserStore userStore;
        private readonly IDbConnection conn;
        private readonly IMapper mapper;
        private readonly IUserService userService;

        public MessageService(
            IUserStore userStore,
            IUserBlockStore userBlockStore,
            IDbConnection conn,
            IMapper mapper,
            IMessageStore messageStore,
            IJWTService jwt)
        {
            this.userStore = userStore;
            this.conn = conn;
            this.mapper = mapper;
            this.messageStore = messageStore;
            this.userBlockStore = userBlockStore;
            this.jwt = jwt;
            this.self = this;
        }

        bool IMessageService.CheckIfReceiverUserExists(string username)
        {
            if (userStore.CheckUsernameIsAvailable(conn, username))
                throw new UserIsNotFoundException();

            return true;
        }

        bool IMessageService.CheckIfUserBlocked(string from, string to)
        {
            if (userBlockStore.CheckIfUserBlockedBy(conn, from, to))
                throw new YouAreBlockedSendingMessageToUserException();

            return true;
        }

        IEnumerable<Message> IMessageService.GetConversation(string token, string withUser)
        {
            var me = jwt.Decode(token).Username;

            IEnumerable<Message> conversation = messageStore.GetConversation(conn, me, withUser);

            return conversation;
        }

        void IMessageService.SendMessage(string token, string toUsername, string body)
        {
            var loginModel = jwt.Decode(token);
            var sender = loginModel.Username;

            self.CheckIfReceiverUserExists(toUsername);

            self.CheckIfUserBlocked(from: toUsername, to: sender);

            var message = new Message()
            {
                Body = body,
                SendDate = DateTime.Now,
                From = sender,
                To = toUsername
            };

            messageStore.Save(conn, message);
        }
    }
}
