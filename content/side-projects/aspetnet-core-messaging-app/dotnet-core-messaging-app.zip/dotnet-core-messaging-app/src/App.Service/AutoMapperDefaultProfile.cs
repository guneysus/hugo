﻿using App.Contracts.Entities;
using App.Models;
using AutoMapper;

namespace App.Service
{
    public class AutoMapperDefaultProfile : Profile
    {
        public AutoMapperDefaultProfile(string profileName) : base(profileName)
        {
            CreateMap<UserRegisterModel, User>().ReverseMap();
        }
    }
}
