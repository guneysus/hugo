﻿using System;
using System.Collections.Generic;

namespace App.Models
{
    public class SendMessageModel
    {
        public string To { get; set; }
        public string Body { get; set; }
    }
   
    public class GetConversationModel
    {
        public string With { get; set; }
    }

    public class ConversationViewModel
    {
        public IList<MessageViewModel> Messages { get; set; }
    }
}
