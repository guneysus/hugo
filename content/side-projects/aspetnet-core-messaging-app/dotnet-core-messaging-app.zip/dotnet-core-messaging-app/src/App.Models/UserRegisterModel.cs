﻿namespace App.Models
{
    public class UserRegisterModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }

    public class BlockUserModel
    {
        public string Username { get; set; }
    }
}
