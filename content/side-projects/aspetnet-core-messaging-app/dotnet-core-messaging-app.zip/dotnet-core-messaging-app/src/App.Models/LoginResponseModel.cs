﻿using System;

namespace App.Models
{
    public class LoginResponseModel
    {
        public string Username { get; set; }
        public long ExpirationTime { get; set; }
    }
}
