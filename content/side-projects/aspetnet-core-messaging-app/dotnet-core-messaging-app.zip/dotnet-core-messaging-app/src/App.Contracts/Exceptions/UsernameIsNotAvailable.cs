﻿using System;

namespace App.Contracts.Exceptions
{
    public class UsernameIsNotAvailableException : Exception { }
    public class UserIsNotFoundException : Exception { }
}
