﻿using System;

namespace App.Contracts.Exceptions
{
    public class LoginUserNameCanNotBeEmpty : Exception { }
}
