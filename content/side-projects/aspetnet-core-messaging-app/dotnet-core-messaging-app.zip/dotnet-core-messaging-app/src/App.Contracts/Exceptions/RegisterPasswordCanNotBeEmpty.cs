﻿using System;

namespace App.Contracts.Exceptions
{
    public class RegisterPasswordCanNotBeEmpty : Exception { }
}
