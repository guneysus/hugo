﻿namespace App.Contracts.Entities
{


    public class UserBlock
    {
        public int Id { get; set; }

        public string User { get; set; }
        public string BlockedUser { get; set; }
    }
}
