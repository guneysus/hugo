﻿using App.Contracts.Entities;
using System.Collections.Generic;

namespace App.Contracts.Service
{
    public interface IMessageService
    {
        void SendMessage(string token, string toUsername, string body);
        IEnumerable<Message> GetConversation(string token, string withUser);
        bool CheckIfUserBlocked(string from, string to);
        bool CheckIfReceiverUserExists(string username);
    }
}
