﻿namespace App.Contracts.Service
{
    public interface IUserService
    {
        void BlockUser(string token, string username);
    }
}
