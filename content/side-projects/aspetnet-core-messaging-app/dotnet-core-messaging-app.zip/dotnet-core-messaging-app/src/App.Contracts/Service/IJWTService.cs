﻿using App.Models;

namespace App.Contracts.Service
{
    public interface IJWTService
    {
        string Encode(string username);
        LoginResponseModel Decode(string token);
    }
}
