﻿using App.Models;

namespace App.Contracts.Service
{
    public interface IAccountService
    {
        void Register(UserRegisterModel model);
        string Login(UserLoginModel model);
    }
}
