﻿using App.Contracts.Entities;
using System.Collections.Generic;
using System.Data;

namespace App.Contracts.Store
{

    public interface IUserStore : IStore<User>
    {
        bool CheckUsernameIsAvailable(IDbConnection conn, string username);
        bool ValidateUsernameAndPassword(IDbConnection conn, string username, string password);
    }
}
