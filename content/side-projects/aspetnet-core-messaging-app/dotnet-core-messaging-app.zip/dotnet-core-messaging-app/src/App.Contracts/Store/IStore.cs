﻿using System.Data;

namespace App.Contracts.Store
{

    public interface IStore<T> where T : class, new()
    {
        T Get(IDbConnection conn, int id);
        void Save(IDbConnection conn, T entity);
        void Delete(IDbConnection conn, int id);
        void CreateTableIfNotExists(IDbConnection conn);
    }
}
