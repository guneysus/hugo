﻿using App.Contracts.Entities;
using System.Data;

namespace App.Contracts.Store
{

    public interface IUserBlockStore : IStore<UserBlock>
    {
        bool CheckIfUserBlockedBy(IDbConnection conn, string user, string blockedUser);
    }
}
