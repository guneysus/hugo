﻿using App.Contracts.Entities;
using System.Collections.Generic;
using System.Data;

namespace App.Contracts.Store
{

    public interface IMessageStore : IStore<Message>
    {
        IEnumerable<Message> GetConversation(IDbConnection conn, object me, string withUser);
    }
}
