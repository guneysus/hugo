﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using App.Contracts.Entities;
using App.Contracts.Store;
using Dapper;

namespace App.Store
{
    public class MessageStore : IMessageStore
    {
        private IMessageStore self;

        public MessageStore(IDbConnection conn)
        {
            self = this;
            self.CreateTableIfNotExists(conn);
        }

        void IStore<Message>.CreateTableIfNotExists(IDbConnection conn)
        {
            conn.Execute(@"
CREATE TABLE IF NOT EXISTS Message (
    Id                      INTEGER         PRIMARY KEY     AUTOINCREMENT   ,
    Body                    NVARCHAR(1000)  NOT NULL                        ,                    
    [From]                  NVARCHAR(50)    NOT NULL                   ,
    SendDate                NVARCHAR(100)   NOT NULL                        ,
    [To]                    NVARCHAR(50)    NOT NULL                    

--    FOREIGN KEY(FromId)     REFERENCES    User(Id)                        ,
--    FOREIGN KEY(ToId)       REFERENCES    User(Id)        
);");
        }

        void IStore<Message>.Delete(IDbConnection conn, int id)
        {
            conn.Execute("DELETE FROM Message WHERE Id = @id", new { id });
        }

        Message IStore<Message>.Get(IDbConnection conn, int id)
        {
            var enumerable = conn.Query<Message>("SELECT * FROM Message WHERE Id = @id", new { id });
            return enumerable.FirstOrDefault();
        }

        void IStore<Message>.Save(IDbConnection conn, Message entity)
        {
            string sql = @"INSERT INTO Message (Body, SendDate, [From], [To]) 
                VALUES (@Body, @SendDate, @From, @To);";

            var result = conn.Execute(sql, entity);
        }

        IEnumerable<Message> IMessageStore.GetConversation(IDbConnection conn, object me, string withUser)
        {
            var sql = @"
            SELECT * FROM Message 
            WHERE ([From] = @me AND [To] = @withUser) OR ([From] = @withUser AND [To] = @me);
";
            var query = conn.Query<Message>(sql, new { me, withUser });
            return query;
        }
    }
}
