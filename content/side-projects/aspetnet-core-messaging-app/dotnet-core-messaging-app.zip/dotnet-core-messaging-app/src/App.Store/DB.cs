﻿using App.Contracts.Store;

namespace App.Store
{
    public class DB
    {
        public readonly IUserStore Users;
        public readonly IMessageStore Messages;
        public readonly IUserBlockStore BlockedUsers;

        public DB(IUserStore users, IMessageStore messages, IUserBlockStore blockedUsers)
        {
            this.Users = users;
            this.Messages = messages;
            this.BlockedUsers = blockedUsers;
        }
    }
}
