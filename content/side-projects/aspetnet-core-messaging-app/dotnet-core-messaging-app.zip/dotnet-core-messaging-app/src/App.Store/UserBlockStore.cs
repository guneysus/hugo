﻿using System.Data;
using System.Linq;
using App.Contracts.Entities;
using App.Contracts.Store;
using Dapper;

namespace App.Store
{
    public class UserBlockStore : IUserBlockStore
    {
        private IUserBlockStore self;

        public UserBlockStore(IDbConnection conn)
        {
            self = this;
            self.CreateTableIfNotExists(conn);
        }

        bool IUserBlockStore.CheckIfUserBlockedBy(IDbConnection conn, string user, string blockedUser)
        {
            var sql = "SELECT COUNT(*) FROM UserBlock WHERE User = @user and BlockedUser = @blockedUser";
            var result = conn.ExecuteScalar<int>(sql, new { user, blockedUser });
            return result > 0;
        }

        void IStore<UserBlock>.CreateTableIfNotExists(IDbConnection conn)
        {
            conn.Execute(@"
CREATE TABLE IF NOT EXISTS UserBlock (
    Id              INTEGER         PRIMARY KEY     AUTOINCREMENT   ,
    User            NVARCHAR(50)    NOT NULL                         ,                    
    BlockedUser     NVARCHAR(50)    NOT NULL                        
);");
        }

        void IStore<UserBlock>.Delete(IDbConnection conn, int id)
        {
            conn.Execute("DELETE FROM UserBlock WHERE Id = @id", new { id });
        }

        UserBlock IStore<UserBlock>.Get(IDbConnection conn, int id)
        {
            var enumerable = conn.Query<UserBlock>("SELECT * FROM UserBlock WHERE Id = @id", new { id });
            return enumerable.FirstOrDefault();
        }

        void IStore<UserBlock>.Save(IDbConnection conn, UserBlock entity)
        {
            if (self.CheckIfUserBlockedBy(conn, entity.User, entity.BlockedUser))
            {
                return;
            }

            string sql = @"INSERT INTO UserBlock (User, BlockedUser) 
                VALUES (@User, @BlockedUser)";
            var result = conn.Execute(sql, entity);
        }
    }
}
