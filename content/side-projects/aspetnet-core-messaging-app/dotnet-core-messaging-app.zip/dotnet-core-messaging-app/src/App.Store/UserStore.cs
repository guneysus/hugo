﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using App.Contracts.Entities;
using App.Contracts.Store;
using Dapper;

namespace App.Store
{
    public class UserStore : IUserStore
    {
        IUserStore self;

        public UserStore(IDbConnection conn)
        {
            self = this;
            self.CreateTableIfNotExists(conn);
        }

        bool IUserStore.CheckUsernameIsAvailable(IDbConnection conn, string username)
        {
            var sql = "SELECT COUNT(*) FROM User WHERE Username = @username";
            var result = conn.ExecuteScalar<int>(sql, new { username });
            return result == 0;
        }

        void IStore<User>.CreateTableIfNotExists(IDbConnection conn)
        {
            var i = conn.Execute(@"
CREATE TABLE IF NOT EXISTS User (
    Id          INTEGER         PRIMARY KEY     AUTOINCREMENT   ,
    Username    VARCHAR(50)     NOT NULL                        ,                   
    Password    VARCHAR(50)     NOT NULL                       
);

CREATE UNIQUE INDEX IF NOT EXISTS UniqueIndex_Username ON User (Username);

");
        }

        void IStore<User>.Delete(IDbConnection conn, int id)
        {
            conn.Execute("DELETE FROM User WHERE Id = @id", new { id });
        }

        User IStore<User>.Get(IDbConnection conn, int id)
        {
            var enumerable = conn.Query<User>("SELECT * FROM User WHERE Id = @id", new { id });
            return enumerable.FirstOrDefault();
        }

        void IStore<User>.Save(IDbConnection conn, User entity)
        {
            string sql = @"INSERT INTO User (Username, Password) 
                VALUES (@Username, @Password)";

            var result = conn.Execute(sql, entity);
        }

        bool IUserStore.ValidateUsernameAndPassword(IDbConnection conn, string username, string password)
        {
            var sql = @"SELECT Password FROM User Where Username = @username";
            var pass = conn.ExecuteScalar<string>(sql, new { username });
            return password == pass;
        }
    }
}
