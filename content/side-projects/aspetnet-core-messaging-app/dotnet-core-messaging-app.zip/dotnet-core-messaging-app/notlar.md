    public static class ApplicationConfigExtensions
    {
        public static void ConfigureApp(this IServiceCollection services)
        {
            services.AddTransient<IUserStore, UserStore>();
            services.AddTransient<IMessageStore, MessageStore>();
            services.AddTransient<IUserBlockStore, UserBlockStore>();
            services.AddTransient<DB>();

            services.AddTransient<IUserService, UserService>();
            services.AddTransient<IAccountService, AccountService>();
            services.AddTransient<IMessageService, MessageService>();

            services.AddTransient<IDbConnection, SQLiteConnection>(x => new SQLiteConnection("Data Source=db.sqlite3;Version=3;"));

        }
    }